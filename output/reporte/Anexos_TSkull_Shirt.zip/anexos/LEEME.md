# Anexos del reporte TSkull-Shirt

Corte 31/10/2026. Acompañan al documento Kubernetes Practica. El registro E01–E14 distingue aprobaciones, alcances parciales y pendientes. Las imágenes son capturas históricas de la ejecución, no pruebas nuevas de la versión 0.1.6.

- diagramas/: siete diagramas Minikube en SVG editable y PNG; son esquemas, no capturas.
- capturas/: siete imágenes esenciales usadas en el informe.
- diccionario-postgresql.csv / restricciones-postgresql.csv: metadatos de columnas y restricciones; sin filas de clientes ni contraseñas.
- diccionario-mongodb.csv / modelo-mongo.json: estructura y ejemplo sintético identificado como tal.
- manual-instalacion-operacion.md: procedimientos y limitaciones del manual.
- registro-E01-E14.csv: fecha, ambiente, requisito, acción, esperado, observado y limitación.
- rendimiento-catalogo.csv / rbac.csv / resultados/: salidas seleccionadas originales. Los análisis de CVE no certifican la imagen final 0.1.6.

No contiene dumps de bases, archivos de credenciales, Secret YAML/JSON, claves TLS, kubeconfig ni respaldos descifrados. Los respaldos reales permanecen privados en la computadora del autor. No es un paquete de despliegue completo ni una evidencia de reconstrucción limpia.
