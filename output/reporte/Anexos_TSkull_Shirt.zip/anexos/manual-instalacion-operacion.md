# Manual de instalación y operación — TSkull-Shirt

Corte: 31/10/2026. Instrucciones documentadas; no certifican reconstrucción limpia. No ejecutar una instalación nueva sobre los perfiles de la entrega.

## D05. Manual de instalación y reanudación

Versiones al corte: Kubernetes 1.37.0, Minikube 1.39.0, containerd 2.3.4, Calico 3.32.2; backend tienda-backend:0.1.6 con PHP 8.3.36, frontend tienda-frontend:0.1.1; Traefik chart 42.1.3/app 3.7.16; kube-prometheus-stack 92.13.1. El repositorio separa aplicación en application/, Dockerfile en docker/php/, pruebas en tests/, producción en k8s/minikube/ y desarrollo en su subcarpeta desarrollo/. Las carpetas kind y overlays previas no son el procedimiento final.

Estos pasos describen la instalación por fases; su reconstrucción completa en recursos limpios no fue ensayada. No aplicarlos indiscriminadamente sobre los ambientes existentes. Los anexos amplían comandos, prerrequisitos, comprobaciones y problemas. Se excluyen de Git k8s/tls/, k8s/secrets.env, .env, output/, tmp/ y vendor/. No se publican valores de credenciales.

## 5.1 Crear la plataforma, solamente en recursos nuevos

Paso 1. Preparar Windows, virtualización, Docker Desktop/WSL 2, Git, Minikube, Helm y mkcert. Abrir Docker, comprobar docker info y resolución de nombres. Construir y probar imágenes con dependencias fijadas. Si Docker no responde, iniciar su motor antes de Minikube. Evidencia: E01 y reportes de imágenes.

```powershell

docker build --target backend -f docker/php/Dockerfile -t tienda-backend:0.1.6 .
docker build --target frontend -f docker/php/Dockerfile -t tienda-frontend:0.1.1 .

```

Paso 2. Crear perfiles independientes con Calico. Cada perfil genera su contexto y red; no sustituirlos por dos namespaces. Verificar get nodes. Ante NotReady, revisar componentes CNI y eventos; no borrar volúmenes para corregir un arranque.

```powershell

minikube start -p tienda-dev --driver=docker --container-runtime=containerd --nodes=1 --cni=calico --cpus=2 --memory=3072 --kubernetes-version=v1.37.0
minikube start -p tienda-prod --driver=docker --container-runtime=containerd --nodes=3 --cni=calico --cpus=2 --memory=3072 --kubernetes-version=v1.37.0

```

Paso 3. En cada perfil habilitar metrics-server y csi-hostpath-driver; cargar las dos imágenes. En producción instalar CSI NFS desde k8s/minikube/csi-nfs-v4.13.0/, servidor-nfs.yaml y volumen-fotos.yaml. Comprobar Pods CSI y PVC Bound; la advertencia de volumesnapshots no demuestra fallo de persistencia y no se ensayaron snapshots.

```powershell

minikube -p tienda-dev addons enable metrics-server
minikube -p tienda-dev addons enable csi-hostpath-driver
minikube -p tienda-dev image load tienda-backend:0.1.6 tienda-frontend:0.1.1
minikube -p tienda-prod addons enable metrics-server
minikube -p tienda-prod addons enable csi-hostpath-driver
minikube -p tienda-prod image load tienda-backend:0.1.6 tienda-frontend:0.1.1

```

## 5.2 Configuración, datos y publicación

Paso 4. Desarrollo: aplicar desarrollo/plataforma.yaml, ejecutar desarrollo/Preparar-Credenciales.ps1 y crear tienda-secrets desde su archivo privado. Producción: preparar namespace/ServiceAccount/ConfigMap, completar k8s/secrets.env.example en un archivo privado y crear su Secret; aplicar seguridad-red.yaml, permisos-operacion.yaml y cuotas-recursos.yaml. Prerrequisito: credenciales de ambos ambientes diferentes. Comprobar RBAC y rechazo de excesos. Nunca mostrar los archivos privados en la terminal de una captura.

```powershell

minikube -p tienda-dev kubectl -- apply -f k8s/minikube/desarrollo/plataforma.yaml
powershell -NoProfile -ExecutionPolicy Bypass -File k8s/minikube/desarrollo/Preparar-Credenciales.ps1
minikube -p tienda-dev kubectl -- create secret generic tienda-secrets -n tienda-dev --from-env-file=k8s/tls/dev-private/secrets.env
minikube -p tienda-prod kubectl -- create secret generic tienda-secrets -n tienda-prod --from-env-file=k8s/secrets.env

```

Paso 5. Aplicar bases-datos.yaml del ambiente; esperar ambos StatefulSets. Aplicar inicializar-tienda.yaml una sola vez, esperar Job complete y revisar logs de migraciones/semilla. En producción existe inicializar-mongo.yaml para preparar el motor. Después activar TLS con Habilitar-TlsPostgres.ps1 y Habilitar-TlsMongo.ps1 y ejecutar sus scripts Comprobar-Tls. La versión final de los manifiestos de aplicación exige las CA: en una instalación nueva el orden TLS debe completarse antes de publicar. El proceso limpio completo sigue pendiente de validar.

```powershell

minikube -p tienda-dev kubectl -- apply -f k8s/minikube/desarrollo/bases-datos.yaml
minikube -p tienda-dev kubectl -- apply -f k8s/minikube/desarrollo/inicializar-tienda.yaml
minikube -p tienda-dev kubectl -- wait --for=condition=complete job/tienda-migrate -n tienda-dev --timeout=300s
minikube -p tienda-prod kubectl -- apply -f k8s/minikube/bases-datos.yaml -f k8s/minikube/inicializar-tienda.yaml

```

Paso 6. Aplicar aplicacion.yaml y tareas-programadas.yaml propios del ambiente. Instalar Traefik chart 42.1.3 con los valores de cada perfil; preparar nombres locales, certificados mkcert, Secret tienda-tls e Ingress entrada-https.yaml. Verificar rollout y HTTPS. Frontend sirve estáticos y delega PHP por FastCGI. Un error 404 al abrir una IP no demuestra bloqueo de firewall: puede faltar una ruta Host.

```powershell

minikube -p tienda-dev kubectl -- apply -f k8s/minikube/desarrollo/aplicacion.yaml -f k8s/minikube/desarrollo/tareas-programadas.yaml
minikube -p tienda-prod kubectl -- apply -f k8s/minikube/aplicacion.yaml -f k8s/minikube/tareas-programadas.yaml
helm upgrade --install traefik traefik/traefik --version 42.1.3 --kube-context tienda-prod -n kube-system -f k8s/minikube/traefik-values.yaml --wait

```

Paso 7. Instalar monitoreo, preparar usuarios de exporters y aplicar metricas-postgres.yaml, metricas-mongo.yaml y alertas-bases.yaml. Programar respaldos a las 20:00. Paso 8. Validar carga, fallos, permisos y restauración aislada según D06–D10. No confundir una actualización correcta con reconstrucción desde cero.

```powershell

helm upgrade --install monitoreo prometheus-community/kube-prometheus-stack --version 92.13.1 --kube-context tienda-prod -n monitoreo --create-namespace -f k8s/minikube/monitoreo-values.yaml --wait --timeout 10m

```

## 5.3 Encender y apagar los ambientes existentes

Abrir Docker Desktop. Iniciar producción conservando el parámetro de cifrado de Secrets y luego desarrollo. Dejar un port-forward por terminal. Las IP LAN deben comprobarse cada vez; la prueba actual de casa usa 192.168.100.3. Al terminar, Ctrl+C en esas terminales, detener ambos perfiles y cerrar Docker Desktop. No usar minikube delete.

```powershell

minikube start -p tienda-prod --extra-config=apiserver.encryption-provider-config=/var/lib/minikube/certs/encryption-config.json
minikube start -p tienda-dev
minikube -p tienda-prod kubectl -- port-forward -n kube-system service/traefik 9443:443 --address=127.0.0.1,192.168.100.3
minikube -p tienda-dev kubectl -- port-forward -n kube-system service/traefik 9444:443 --address=127.0.0.1
minikube -p tienda-prod kubectl -- port-forward -n monitoreo service/monitoreo-grafana 3000:80 --address=127.0.0.1
minikube stop -p tienda-dev
minikube stop -p tienda-prod

```

## Condiciones pendientes antes de reconstruir desde cero

Los Jobs inicializar-tienda.yaml/inicializar-mongo.yaml conservan referencias a tienda-backend:0.1.0. El despliegue final usa 0.1.6. Alinear y validar esas referencias en una instalación de prueba; no sustituirlas silenciosamente ni prometer que una imagen antigua contiene todas las migraciones actuales.

La migración/semilla se ejecuta por Job, no en cada réplica. No resembrar ni copiar producción hacia desarrollo. El material privado bajo k8s/tls no forma parte del repositorio ni de este paquete.

La habilitación inicial de cifrado etcd modifica el API server: requiere su copia protegida de clave y un plan de recuperación. El arranque de un perfil ya cifrado utiliza el parámetro encryption-provider-config documentado. Un perfil nuevo todavía no tiene ese archivo: prepararlo antes de usar ese parámetro.

La prueba E14, la etiqueta Git final, la centralización de logs, el máximo de conexiones y la medición integral de RPO/RTO continúan pendientes. No se realizaron instalaciones, despliegues ni cambios de datos para redactar este informe.

## Solución de incidencias observadas

Ruta YAML inexistente: ubicarse en C:\laragon\www\sistema o usar ruta absoluta. No ejecutar apply desde C:\Users\josem con rutas relativas del proyecto.

Puerto ocupado: conservar el proceso conocido o elegir puerto libre; restauración usó 9081 en vez de 9080. No terminar procesos desconocidos.

PowerShell: primero asignar $revisionAnterior y después validarla en otra línea. Guardar revisión e imagen antes de actualizar. rollout undo no revierte el esquema SQL.

Reinicio prolongado: comprobar estado de Calico y DNS. Un error de token del CNI requirió renovar sus Pods mediante un rollout controlado; no borrar datos del perfil.

Restauración tar: diferencias de permisos/GID no equivalen a corrupción de contenido. La validación final usa SHA256 de archivos y verifica registros e índices; conserva el intento fallido y no suma solo el tiempo de continuación como RTO total.

Exporters Running con pg_up/mongodb_up=0: revisar autenticación, TLS y políticas; Running no acredita acceso al motor. La corrección MongoDB 2.x usa las opciones esperadas por el driver y fue validada mediante Job.

Acceso por IP con 404: comprobar Host, regla IngressRoute y proveedor CRD de Traefik. Una conexión local correcta no demuestra por sí sola el acceso LAN ni el bloqueo de desarrollo.
